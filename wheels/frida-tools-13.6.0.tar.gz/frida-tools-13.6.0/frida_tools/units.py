def bytes_to_megabytes(b: float) -> float:
    return b / (1024 * 1024)
